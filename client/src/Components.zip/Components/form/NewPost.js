
import "./NewPost.modules.css"
import SubmitButton from "./SubmitButton";
import cam from "../cam.png"
import { useState } from "react";
import Axios from "axios";


function NewPost(){
    const [texto, setTexto] = useState();    
    const [imagem, setImagem] = useState();
    const [user, setUser] = useState('fybs'); //coloquei esse user padrão pq ainda não sei como pegar o usuário logado

    const sendPost = () => {
        Axios.post("http://localhost:3001/createpost", { //essa função envia os dados para o backend
        texto: texto,
        user: user,
        imagem: imagem,
        }).then(() => {
            console.log("success"); 
        });
    }

    return (
        <form className="form">
            <div>
                <label>O que você está jogando hoje?</label>
            </div>
            <textarea name="texto" onChange={(event) => {
                      setTexto(event.target.value);}}>
            </textarea>      

            <div className="imageContainer">
                <img src={cam} alt="Selecione uma imagem" id="imgphoto"></img>
                <input type="file" id="postimage" name="postimage" accept="image/*" onChange={(event) => {
                      setImagem(event.target.value);}}></input>
            </div>


            
            <div className="form_control">
                <button className="btn" onClick={sendPost}>Publicar</button>
            </div>  
        </form>
    )
}

export default NewPost;
