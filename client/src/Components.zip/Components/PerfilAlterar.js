import { useState } from "react";
import "./Perfil.modules.css";
import Axios from "axios";
import Navbar from "./layout/Navbar";
import Footer from "./layout/Footer";
import Globais from "./Globais";

function PerfilAlterar(){  //falta salvar as alterações no banco de dados
 
    let userName = Globais.user;
    const [newUser, setNewUser] = useState("");
    const [newEmail, setNewEmail] = useState("");
    const [newDescricao, setNewDescricao] = useState("");
    const [imagem, setImagem] = useState("")
    let email = "";
    let descricao = "";
    let image = ""
    
    const [perfil, setPerfil] = useState([]);

    const getProfile = () => {
        Axios.get("http://localhost:3001/users").then((response) => { //pega os dados do backend
          setPerfil(response.data);
      });

      let i = 0;
      while (i < perfil.length){    //encontra os dados através do user conectado
        if (userName === perfil[i].userName) {
            descricao = perfil[i].descricao;
            email = perfil[i].email;
            image = perfil[i].imagem
            i = perfil.length;
        }
        i = i + 1;
      } 
    }

    const alterarDados = () => {
        if (newUser === "") { setNewUser(userName) };
        if (newEmail === "") { setNewEmail(email)};
        if (newDescricao === "") { setNewDescricao(descricao)};
        if (imagem === "") { setNewDescricao(descricao)};
    
    }
    

    getProfile();

    return (
        <div>
            <Navbar />
            <h1>Perfil</h1>            
            <div>
                <label  className="form_control">Foto de perfil</label>
                <input 
                type="file" 
                id="newimage" 
                name="newimage" 
                accept="image/*" 
                onChange={(event) => {
                      setImagem(event.target.value);}}/>
            </div>
            <div>
                <label  className="form_control">Nome de usuário</label>
                <input
                type="text"
                text="nome_de_usuario"
                name="newUser"
                placeholder={userName}
                onChange={(event) => {
                    setNewUser(event.target.value);
                }}
                />
            </div>
            <div>
                <label className="form_control">Email</label>
                <input
                type="text"
                text="email"
                name="email"
                placeholder={email}
                onChange={(event) => {
                    setNewEmail(event.target.value);
                }}
                />
            </div>
            <div>
                <label className="form_control">Descrição</label>
                <input
                type="descricao"
                text="descricao"
                name="newDescricao"
                placeholder={descricao}
                onChange={(event) => {
                    setNewDescricao(event.target.value);
                }}
                />
            </div>
            
            <div>
                <button onClick={alterarDados}>Salvar alterações</button>
            </div>
        < Footer />
        </div>
    );
}

export default PerfilAlterar;