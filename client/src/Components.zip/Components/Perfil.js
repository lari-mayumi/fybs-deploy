import { useState } from "react";
import "./Perfil.modules.css";
import Axios from "axios";
import { Link } from 'react-router-dom';
import Globais from "./Globais";
import Navbar from "./layout/Navbar";
import Footer from "./layout/Footer";

function Perfil(){

    let user = Globais.user;
    const [userName, setUserName] = useState(Globais.user);
    let email = "";
    let descricao = "";
    
    const [perfil, setPerfil] = useState([]);

    const getProfile = () => {
        Axios.get("http://localhost:3001/users").then((response) => { //pega os dados do backend
            //console.log(response.data);
          setPerfil(response.data);
      });
      console.log(userName, email, descricao);
      let i = 0;
      while (i < perfil.length){    //encontra os dados através do user conectado
        if (userName === perfil[i].userName) {
            console.log("achei")
            descricao = perfil[i].descricao;
            email = perfil[i].email;
            i = perfil.length;
        }
        i = i + 1;
      } 
    }

    getProfile();    //trocar a label de alterar dados para botão

    return (
        <div>
            < Navbar />

            <h1>Perfil</h1>
            <div>
                <label  className="form_control">Nome de usuário</label>
                <label className="form_control">@{user}</label>
            </div>
            <div>
                <label className="form_control">Email</label>
                <label className="form_control">{email}</label>
            </div>
            <div>
                <label className="form_control">Descrição</label>
                <label className="form_control">{descricao}</label>
            </div>

            <button><Link to="/alterarperfil">Alterar dados</Link></button>
            
            <Footer />
        </div>
    );
}

export default Perfil;

////<button ><Link to="/alterarperfil" ></Link>Alterar dados</button>