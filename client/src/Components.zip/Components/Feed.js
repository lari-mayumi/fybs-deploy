import NewPost from "./form/NewPost";
import Post from "./Post";
import { useState } from "react";
import Axios from "axios";
import Navbar from "./layout/Navbar";
import Footer from "./layout/Footer";

function Feed(){
    const [postList, setPostList] = useState([]);

    const getPosts = () => {
      Axios.get("http://localhost:3001/posts").then((response) => { //pega os dados do backend
        //console.log("Função getPosts: ", postList);
        setPostList(response.data);
    });
    }

    getPosts();

    return ( 
        <div>
          <Navbar />
          < NewPost />
         
          {postList.map((val, key) => {
            return (
              <Post user={'@' + val.userName} texto={val.text}/>
            )
          })}


        < Footer />
        </div>  
        
    )
}

export default Feed;

//<button className="btn" onClick={< NewPost />}>Nova Postagem</button> 

/**
 *  <Post user="@Stezinha" texto="Fofoca? Aceito!"/>
          
          <Post user="@Lari" texto="Sushi fofinho"/>
          
          <Post user="@Mandita" texto="Edward seu lindo"/>
          
          <Post user="@Tate" texto="vo dar paulada"/>
 * 
      {postList.map((val, key) => {
          return (
            <div>
                <h3> {val.userName}</h3>
                <h3>{val.text}</h3>
           </div>
          );
        })}
 */