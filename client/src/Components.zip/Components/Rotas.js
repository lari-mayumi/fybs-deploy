import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Redirect } from 'react-router-dom';

import NovaConta from './NovaConta';
import Login from './Login';
import Feed from './Feed';
import NewPost from './form/NewPost';
import Perfil from './Perfil';
import PerfilAlterar from './PerfilAlterar';
import { Component } from 'react';
import Globais from './Globais';
import Navbar from './layout/Navbar';
import Footer from './layout/Footer';

function Rotas(){
    const PrivateRoute = ({ component: Component, ...rest }) => (
      <Route
       {...rest} 
       render={props => 
        Globais.login = 1 ? (
          <Component {...props} />
        ) : (
          //<Redirect to={{ pathname: '/', state: { from: props.location } }} />
          console.log("Vai entrar n")
        
         )
      }
    />
    );

    return(
      < div >
        <Routes>
        <Route exact path="/" element={< Login />} />
        <Route exact path="/cadastrar" element={< NovaConta />} />
        <Route exact path="/feed" element={< Feed />} />
        <Route exact path="/feed/post" element={< NewPost />} />
        <Route exact path="/perfil" element={< Perfil />} />
        <Route exact path="/alterarperfil" element={< PerfilAlterar />} />

        </Routes>
      </ div >
    )
}

export default Rotas;

//<PrivateRoute exact path="/feed" element={< Feed />} />