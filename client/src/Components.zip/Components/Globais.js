export default class Globais{
    static user = "";
    login = 0;
}