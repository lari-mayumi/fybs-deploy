import "./Post.modules.css";

function Post({user, texto}){
    return (
        <div className="post">
            <div className="user">
                <header>{user}</header>
            </div>
            
            <p className="texto">{texto}</p>
            
             <p> </p>
        </div>
    )

}

export default Post;