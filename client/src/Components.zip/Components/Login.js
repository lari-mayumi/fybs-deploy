import '../App.css';
import { useState } from "react";
import Axios from "axios";
import "./Login.modules.css";
import Globais from "./Globais";
import { Link, useNavigate } from 'react-router-dom';
import NovaConta from './NovaConta';
import NavbarInicial from './layout/NavbarInicial';
import Footer from "./layout/Footer";

function Login(){
  const [userList, setUserList] = useState([]);
  const [name, setName] = useState();
  const [senha, setSenha] = useState();
  const [caminho, setCaminho] = useState();

  const navigate = useNavigate();

  const getUsers = () => {
    Axios.get("http://localhost:3001/users").then((response) => {
      //console.log(userList);
      setUserList(response.data);
    });

    let i=0;
    while (i < userList.length) {
      if (userList[i].nome === name && userList[i].senha === senha) { //está duplicando os users e precisa clicar duas vezes no botão pra logar, na primeira da erro
        console.log("Achei:", name, senha);
        Globais.login = 1;
      }
      i = i + 1;  
    }

    if (Globais.login === 1) {
      //ir para o feed
      Globais.user = name;
      //setCaminho('/feed'); //busca no banco configurada, precisamos descobrir como mudar de página
      //<Link to="/feed">Alterar dados</Link>
      navigate("/feed");
      console.log("entrando")
    }
    else {
      console.log("Usuário ou senha inválidos."); //fazer popup para mostrar isso
    }
  };


    return(
        <div className="form_control">
          < NavbarInicial />
          <label>Nome de Usuário ou Email</label>
          <div>
            <input 
                  type="text"
                  text="Nome de Usuário ou Email"
                  name="name"
                  placeholder="Insira o nome de usuário ou email"
                  onChange={(event) => {
                      setName(event.target.value);
                  }}
            />   
          </div>
          <label>Senha</label>
          <div>
            <input 
                  type="password"
                  text="Senha"
                  name="senha"
                  placeholder="Insira a senha"
                  onChange={(event) => {
                      setSenha(event.target.value);
                  }}
            />
          </div>
          <div>
            <button onClick={getUsers}>Entrar</button>
          
          <div>
            <label><Link to="/cadastrar">Criar Conta</Link></label>
          </div>

            
          </div>            
          < Footer />
        </div>
    )
}

export default Login;