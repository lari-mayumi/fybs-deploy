import {Link} from 'react-router-dom'
import Container from './Container';
import logo from '../../img/logo.png'

function NavbarInicial(){
    return (
    <nav className="navbar">
        <Container>
            <Link to="/">
                <img src={logo} alt="fybs" />
            </Link>
        </Container>
    </nav>
    )
}

export default NavbarInicial;

/**
 * 
            <ul className="list">
                <li className="item">
                    <Link to="/">Login</Link>
                </li>
                <li className="item">
                    <Link to="/feed">Feed</Link>
                </li>
                <li className="item">
                    <Link to="/cadastrar">Criar Conta</Link>
                </li>
                <li className="item">
                    <Link to="/perfil">Perfil</Link>
                </li>
            </ul>
 */