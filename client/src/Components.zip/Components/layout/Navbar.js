import {Link} from 'react-router-dom'
import Container from './Container';
import "./Navbar.modules.css";
import logo from '../../img/logo.png'
import Globais from '../Globais';

function Navbar(){
    const logout = () =>{
        Globais.login = 0;
    }

    return (
    <nav className="navbar">
        <Container>
            <Link to="/">
                <img src={logo} alt="fybs" />
            </Link>
            <ul className="list">
                <li className="item">
                    <Link to="/feed">Feed</Link>
                </li>
                <li className="item">
                    <Link to="/perfil">Perfil</Link>
                </li>
                <li className="item">
                    <Link to="/" onClick={logout}>Logout</Link>
                </li>
            </ul>
        </Container>
    </nav>
    )
}

export default Navbar;